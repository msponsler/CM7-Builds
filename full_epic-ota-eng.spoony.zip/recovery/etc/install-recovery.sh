#!/system/bin/sh
if ! applypatch -c MTD:recovery:2048:eeb1a4678729ca330cb47282a932ea93c51c0d30; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:6692864:eff33c7cc2fc9daa2a820802207692ffd4a7c1f5 MTD:recovery 56fd1ad22f79ff9bcfc890362490623937dfbf51 7821312 eff33c7cc2fc9daa2a820802207692ffd4a7c1f5:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
